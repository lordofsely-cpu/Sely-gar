# Remote screen viewing — NOT implemented
Android side today: consent dialog, visible foreground service, MediaProjection capture at ~480px/2 fps into `FrameSink`.
`DiscardSink` throws frames away. To add viewing, you must build and deploy (none of this exists):
1. Backend: device registration + short-lived tokens, viewer authorization, TLS only, rate limiting, audit log, no stored frames by default.
2. A `FrameSink` that sends over TLS (WebRTC with TURN, or WebSocket + JPEG) with per-session tokens.
3. A per-session consent rule: the device user must approve each session (Android already forces a new system prompt each time).
4. Failure handling: the service already stops after 3 consecutive sink errors; reconnect policy is yours to define.
