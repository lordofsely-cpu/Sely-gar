package com.sely.guardian

import com.sely.guardian.data.RestrictionText
import org.junit.Assert.assertEquals
import org.junit.Test

class RestrictionTextTest {
    @Test fun studyMessageMatchesSpec() = assertEquals(
        listOf("SELY GUARDIAN", "This application is restricted during Study Mode.",
            "Please return to your scheduled activities.", "Managed by your authorized administrator."),
        RestrictionText.lines(RestrictionText.modeName("ACTIVE", "OUTSIDE")))
    @Test fun bedtimeWinsWhenBothActive() = assertEquals("Bedtime Mode", RestrictionText.modeName("ACTIVE", "ACTIVE"))
    @Test fun unknownFallsBack() = assertEquals("a scheduled mode", RestrictionText.modeName(null, "OUTSIDE"))
}
