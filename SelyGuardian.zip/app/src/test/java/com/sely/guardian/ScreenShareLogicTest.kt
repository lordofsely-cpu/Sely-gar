package com.sely.guardian

import com.sely.guardian.screenshare.FrameThrottle
import com.sely.guardian.screenshare.ScreenGeometry
import org.junit.Assert.*
import org.junit.Test

class ScreenShareLogicTest {
    @Test fun scalesDownKeepingAspect() = assertEquals(480 to 1066, ScreenGeometry.scaled(1080, 2400, 480))
    @Test fun neverUpscales() = assertEquals(320 to 640, ScreenGeometry.scaled(320, 640, 480))
    @Test fun alwaysEven() { val (w, h) = ScreenGeometry.scaled(1081, 2401, 481); assertEquals(0, w % 2); assertEquals(0, h % 2) }
    @Test fun badSizeIsSafe() = assertEquals(2 to 2, ScreenGeometry.scaled(0, 0, 480))
    @Test fun throttleAllowsFirstThenWaits() {
        val t = FrameThrottle(500)
        assertTrue(t.shouldProcess(1000)); assertFalse(t.shouldProcess(1200)); assertTrue(t.shouldProcess(1500))
    }
}
