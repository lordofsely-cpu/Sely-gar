package com.sely.guardian.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.sely.guardian.location.LocationControl
import com.sely.guardian.location.LocationState
import com.sely.guardian.ui.GuardianViewModel
import kotlinx.coroutines.flow.update
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val fmt = DateTimeFormatter.ofPattern("MMM d HH:mm:ss")
private fun ts(ms: Long) = fmt.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

@Composable
fun LocationScreen(vm: GuardianViewModel) {
    val ctx = LocalContext.current
    val st by LocationState.flow.collectAsState()
    var interval by remember { mutableStateOf(if (st.intervalSec > 0) st.intervalSec else 300) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true || res[Manifest.permission.ACCESS_COARSE_LOCATION] == true) LocationControl.start(ctx, interval)
        else LocationState.flow.update { it.copy(message = "Location permission denied. Sharing was not started.") }
    }
    val notifOff = Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Location sharing", style = MaterialTheme.typography.headlineMedium)
        if (st.active) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Column(Modifier.padding(12.dp)) {
                    Text("SHARING IS ACTIVE", style = MaterialTheme.typography.titleMedium)
                    Text("Updating about every ${st.intervalSec / 60} min. A notification stays visible while this is on.")
                }
            }
            Button(onClick = { LocationControl.stop(ctx) }) { Text("Stop sharing") }
        } else {
            Text("Sharing is OFF.")
            Text("Update interval", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(60, 300, 900).forEach { s -> FilterChip(interval == s, { interval = s }, { Text("${s / 60} min") }) }
            }
            Button(onClick = {
                val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                launcher.launch(perms.toTypedArray())
            }) { Text("Start sharing") }
        }
        st.message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (notifOff) Text("Notification permission is off, so the sharing indicator will not appear in your notification shade. This banner still shows in the app.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Latest location", style = MaterialTheme.typography.titleMedium)
                val f = st.fix
                if (f == null) Text("No location yet. Start sharing, or location may be unavailable indoors or switched off.")
                else {
                    Text("Latitude / longitude: %.5f, %.5f".format(f.lat, f.lon))
                    Text("Accuracy: about ±${f.accuracyM.toInt()} m (${f.provider})")
                    Text("Fix time: ${ts(f.timeMs)}")
                    Text("Last successful update: ${st.lastUpdateMs?.let(::ts) ?: "not in this session"}")
                }
            }
        }
        if (st.fix != null && !st.active) OutlinedButton(onClick = { vm.deleteStoredLocation() }) { Text("Delete stored location") }

        Text("What this does", style = MaterialTheme.typography.titleMedium)
        Text("What: reads this device's location at the interval you choose. Why: so an authorized administrator can see where the device is. " +
            "When: only while sharing is ON; it never starts by itself, not even after a restart. Stop any time with the button or the notification.")
        Text("Local only: remote sharing needs a backend, which does not exist yet, so nothing leaves this phone. Only the latest fix is stored here; coordinates are never written to the log.",
            style = MaterialTheme.typography.bodySmall)
        Text("Battery and Android limits: shorter intervals use more battery. If you allow only approximate location, accuracy is lower. Android may pause updates in deep battery saving.",
            style = MaterialTheme.typography.bodySmall)
    }
}
