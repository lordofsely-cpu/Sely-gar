package com.sely.guardian.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.sely.guardian.data.UsageCalc.fmtDuration
import com.sely.guardian.ui.GuardianViewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private val tsFmt = DateTimeFormatter.ofPattern("MMM d HH:mm")

@Composable
fun ReportsScreen(vm: GuardianViewModel) {
    val ctx = LocalContext.current
    val r by vm.usage.collectAsState()
    val hist by vm.history.collectAsState()
    var week by remember { mutableStateOf(false) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.refreshUsage() }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Screen time", style = MaterialTheme.typography.headlineMedium) }
        val x = r
        if (x == null) { item { Text("Loading…") } }
        else if (!x.hasAccess) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Usage Access is off, so there is no data to show.", style = MaterialTheme.typography.titleMedium)
                        x.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Text("Why: Android only reports how long apps were used if you allow Usage Access. Sely only reads app names and foreground time, on this device.")
                        Text("How: Settings > Apps > Special app access > Usage access > Sely Guardian > Allow (menu names vary by phone).",
                            style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                            Text("Open Usage Access settings")
                        }
                    }
                }
            }
        } else {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(!week, { week = false }, { Text("Today") })
                    FilterChip(week, { week = true }, { Text("Last 7 days") })
                }
            }
            val total = if (week) x.weekTotal else x.todayTotal
            val top = if (week) x.weekTop else x.todayTop
            item { Text("Total: ${fmtDuration(total)}", style = MaterialTheme.typography.titleLarge) }
            if (week) item {
                val max = (x.daily.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    x.daily.forEach { (d, ms) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(fmtDuration(ms), style = MaterialTheme.typography.labelSmall)
                            Box(Modifier.width(24.dp).height((ms * 90 / max).coerceAtLeast(2).dp).background(MaterialTheme.colorScheme.primary))
                            Text(d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            item { Text("Most-used apps", style = MaterialTheme.typography.titleMedium) }
            if (top.isEmpty()) item { Text("No usage recorded for this period.") }
            items(top) { a -> Row(Modifier.fillMaxWidth()) { Text(a.name, Modifier.weight(1f)); Text(fmtDuration(a.millis)) } }
            item { Text("Figures are approximate (built from app foreground events; Android keeps only about a week).", style = MaterialTheme.typography.bodySmall) }
        }
        fun ts(ms: Long) = tsFmt.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))
        item { Text("Study / Bedtime history", style = MaterialTheme.typography.titleMedium) }
        val modes = hist.filter { it.event == "state_change" }
        if (modes.isEmpty()) item { Text("No changes recorded yet.") }
        items(modes.take(30)) { Text("${ts(it.ts)}  ${it.mode}: ${it.detail}", style = MaterialTheme.typography.bodySmall) }
        item { Text("Restriction events", style = MaterialTheme.typography.titleMedium) }
        val blocks = hist.filter { it.event == "blocked_launch" }
        if (blocks.isEmpty()) item { Text("None recorded. Only the Accessibility blocker records these; Device Owner suspension does not report launch attempts.", style = MaterialTheme.typography.bodySmall) }
        items(blocks.take(30)) { Text("${ts(it.ts)}  blocked launch of ${it.detail}", style = MaterialTheme.typography.bodySmall) }
        item { Text("History shows when this app detected a change, which can be later than the real moment if the phone was off.", style = MaterialTheme.typography.bodySmall) }
    }
}
