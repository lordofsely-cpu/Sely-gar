package com.sely.guardian.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.sely.guardian.data.*
import com.sely.guardian.enforce.CompositeEnforcer
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class Diagnostics(
    val exactAlarmsAllowed: Boolean,
    val nextAtMillis: Long?, val nextMode: String?, val nextState: String?, val nextExact: Boolean?,
    val lastPolicy: String?, val log: List<LogRow>,
)

/**
 * Single entry point for schedule work. reconcile() is idempotent: it recomputes state from stored config and the
 * current clock, applies the resolved policy, logs, and (re)arms ONE alarm (same PendingIntent, so no duplicates).
 * Called on app start, config change, alarm, boot, time/time-zone change, app update, and an hourly WorkManager net.
 */
class ScheduleManager(ctx: Context, private val enforcer: Enforcer = CompositeEnforcer(ctx)) {
    private val app = ctx.applicationContext
    private val db = GuardianDb.of(app)
    private val store = SettingsStore(app)

    fun reconcile(reason: String): String = synchronized(LOCK) {
        val now = LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES)
        val study = store.loadMode("study", Defaults.study)
        val bed = store.loadMode("bedtime", Defaults.bedtime)
        val sel = store.loadSelection()
        val ss = ScheduleCalc.state(study, now)
        val bs = ScheduleCalc.state(bed, now)
        trackState("study", ss); trackState("bedtime", bs)
        listOf("study" to study, "bedtime" to bed).forEach { (n, c) ->
            val errs = ScheduleCalc.validate(c)
            if (c.enabled && errs.isNotEmpty()) db.log(n, "invalid_config", errs.joinToString(" "))
        }
        val policy = PolicyResolver.resolve(ss, bs, sel)
        val report = try { enforcer.apply(policy) } catch (e: Exception) { EnforcementReport(false, "enforcer error: ${e.javaClass.simpleName}") }
        val summary = "modes=${policy.activeModes.joinToString("+").ifEmpty { "none" }} restricted=${policy.restricted.size} " +
            "enforced=${report.enforced} (${report.message})"
        db.log("policy", "reconcile:$reason", summary)
        db.put("last_policy", summary)
        val next = listOfNotNull(
            ScheduleCalc.nextTransition(study, now)?.let { Triple("study", it.at, it.to) },
            ScheduleCalc.nextTransition(bed, now)?.let { Triple("bedtime", it.at, it.to) },
        ).minByOrNull { it.second }
        arm(next)
        ReconcileWorker.ensureScheduled(app)
        summary
    }

    private fun trackState(mode: String, s: ScheduleState) {
        val prev = db.get("last_state_$mode")
        if (prev != s.name) {
            db.log(mode, "state_change", "${prev ?: "none"} -> ${s.name} (detected ${LocalDateTime.now().withNano(0)})")
            db.put("last_state_$mode", s.name)
        }
    }

    private fun alarmManager() = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private fun canExact(am: AlarmManager) = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()

    private fun pending(): PendingIntent = PendingIntent.getBroadcast(
        app, 1, Intent(app, ScheduleReceiver::class.java).setAction(ACTION_ALARM),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun arm(next: Triple<String, LocalDateTime, ScheduleState>?) {
        val am = alarmManager()
        val pi = pending()
        if (next == null) { am.cancel(pi); db.put("next_alarm", ""); return }
        var at = ScheduleCalc.toMillis(next.second, ZoneId.systemDefault())
        val nowMs = System.currentTimeMillis()
        if (at <= nowMs) at = nowMs + 1000
        var exact = canExact(am)
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            exact = false
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            db.log("alarm", "exact_denied", "fell back to inexact alarm")
        }
        db.put("next_alarm", "$at|${next.first}|${next.third.name}|$exact")
    }

    fun diagnostics(): Diagnostics {
        val parts = db.get("next_alarm")?.takeIf { it.isNotBlank() }?.split("|")
        return Diagnostics(
            exactAlarmsAllowed = canExact(alarmManager()),
            nextAtMillis = parts?.getOrNull(0)?.toLongOrNull(), nextMode = parts?.getOrNull(1),
            nextState = parts?.getOrNull(2), nextExact = parts?.getOrNull(3)?.toBooleanStrictOrNull(),
            lastPolicy = db.get("last_policy"), log = db.recentLog(60),
        )
    }

    companion object {
        const val ACTION_ALARM = "com.sely.guardian.ACTION_SCHEDULE_ALARM"
        private val LOCK = Any()
    }
}
