package com.sely.guardian.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0A1633)
val Royal = Color(0xFF1F4FD8)
val Cyan = Color(0xFF22D3EE)
val AlertRed = Color(0xFFE5484D)

private val Dark = darkColorScheme(
    primary = Cyan, onPrimary = Navy, secondary = Royal, background = Navy,
    surface = Color(0xFF12214A), onBackground = Color.White, onSurface = Color.White, error = AlertRed
)
private val Light = lightColorScheme(
    primary = Royal, onPrimary = Color.White, secondary = Cyan, background = Color.White,
    surface = Color(0xFFF1F5FF), onBackground = Navy, onSurface = Navy, error = AlertRed
)

@Composable
fun SelyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
