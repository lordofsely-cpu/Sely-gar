package com.sely.guardian.screenshare

import android.media.Image
import kotlinx.coroutines.flow.MutableStateFlow

object ScreenGeometry {
    /** Scales down to at most [maxW] wide (never up), keeps aspect ratio, forces even sizes. */
    fun scaled(w: Int, h: Int, maxW: Int): Pair<Int, Int> {
        if (w <= 0 || h <= 0) return 2 to 2
        val tw = minOf(w, maxW)
        val th = (h.toLong() * tw / w).toInt()
        return (tw and 1.inv()).coerceAtLeast(2) to (th and 1.inv()).coerceAtLeast(2)
    }
}

class FrameThrottle(private val minIntervalMs: Long) {
    private var last = Long.MIN_VALUE / 2
    fun shouldProcess(now: Long): Boolean {
        if (now - last >= minIntervalMs) { last = now; return true }
        return false
    }
}

/** Seam for remote viewing (not implemented). A real sink would send frames over TLS to an authenticated backend. */
interface FrameSink {
    fun onFrame(width: Int, height: Int, image: Image)
    val description: String
}

/** Default sink: frames are counted and DISCARDED. Nothing is stored or transmitted. */
object DiscardSink : FrameSink {
    override fun onFrame(width: Int, height: Int, image: Image) {}
    override val description = "local counter only (frames discarded, nothing sent or stored)"
}

data class ShareUiState(
    val active: Boolean = false, val frames: Long = 0, val width: Int = 0, val height: Int = 0,
    val startedMs: Long? = null, val lastFrameMs: Long? = null, val sink: String = DiscardSink.description, val message: String? = null,
)

/** In-memory only: sharing can never silently resume after a restart; each session needs fresh system consent. */
object ScreenShareState { val flow = MutableStateFlow(ShareUiState()) }
