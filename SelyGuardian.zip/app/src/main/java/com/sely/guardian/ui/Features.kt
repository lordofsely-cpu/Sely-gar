package com.sely.guardian.ui

enum class Status(val label: String) { PLANNED("Not implemented yet"), SHELL("Built, untested on a device"), DONE("Working") }

/** Single source of truth for the feature checklist; update as each stage lands. */
data class Feature(val route: String, val title: String, val stage: Int, val status: Status, val note: String)

val features = listOf(
    Feature("apps", "App Management", 2, Status.SHELL, "Discovery, search, categories and saved selections work. Blocking is not enforced."),
    Feature("study", "Study Mode", 2, Status.SHELL, "Settings and schedule status saved locally. Schedule engine (alarms, reboot/time-zone recovery) built but unverified on a device; enforcement needs Device Owner or the Accessibility blocker (Dashboard > Protection), both unverified."),
    Feature("bedtime", "Bedtime Mode", 2, Status.SHELL, "Settings and schedule status saved locally. Schedule engine (alarms, reboot/time-zone recovery) built but unverified on a device; enforcement is stage 4."),
    Feature("reports", "Screen Time Reports", 5, Status.SHELL, "Needs Usage Access. Figures are approximate; never fabricated."),
    Feature("location", "Location Sharing", 5, Status.SHELL, "Visible foreground service, local only. Remote sharing needs the backend."),
    Feature("screen", "Screen Sharing", 6, Status.SHELL, "Consent + visible capture pipeline only. Remote viewing needs a backend."),
    Feature("admin", "Administrator Settings", 7, Status.PLANNED, "PIN via Android Keystore."),
)
