package com.sely.guardian.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sely.guardian.data.*
import androidx.compose.ui.platform.LocalContext
import com.sely.guardian.enforce.Enforcement
import com.sely.guardian.enforce.Mechanism
import java.time.LocalDateTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeButton(label: String, minutes: Int, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = true }) { Text("$label ${fmtMin(minutes)}") }
    if (open) {
        val st = rememberTimePickerState(minutes / 60, minutes % 60, true)
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { onPick(st.hour * 60 + st.minute); open = false }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Cancel") } },
            text = { TimePicker(state = st) },
        )
    }
}

@Composable
fun TimeRow(r: TimeRange, onChange: (TimeRange) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TimeButton("From", r.startMin) { onChange(r.copy(startMin = it)) }
        TimeButton("To", r.endMin) { onChange(r.copy(endMin = it)) }
    }
}

private val dayLabels = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

@Composable
fun ModeScreen(
    title: String, config: ModeConfig, sel: AppSelection,
    supportsBreaks: Boolean, supportsWeekend: Boolean,
    onChange: ((ModeConfig) -> ModeConfig) -> Unit, onManageApps: () -> Unit,
) {
    val state = ScheduleCalc.state(config, LocalDateTime.now())
    val errors = ScheduleCalc.validate(config)
    val mech = Enforcement.mechanism(LocalContext.current)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Enabled", Modifier.weight(1f)); Switch(config.enabled, { v -> onChange { it.copy(enabled = v) } })
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Schedule status: ${state.label}")
                Text(if (mech == Mechanism.NONE) "Enforcement: NONE. No app is blocked. Set up under Dashboard > Protection." else "Enforcement: ${mech.label}",
                    color = if (mech == Mechanism.NONE) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                Text("${sel.restricted.size} restricted · ${sel.allowed.size} allowed (chosen in Apps)", style = MaterialTheme.typography.bodySmall)
            }
        }
        errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
        Text("Days")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            dayLabels.forEachIndexed { i, l ->
                val d = i + 1
                FilterChip(d in config.days, { onChange { c -> c.copy(days = if (d in c.days) c.days - d else c.days + d) } }, { Text(l) })
            }
        }
        Text(if (supportsWeekend && config.weekendWindow != null) "Weekday times" else "Times")
        TimeRow(config.window) { w -> onChange { it.copy(window = w) } }
        if (supportsWeekend) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Different Sat/Sun times", Modifier.weight(1f))
                Switch(config.weekendWindow != null, { on -> onChange { it.copy(weekendWindow = if (on) it.window else null) } })
            }
            config.weekendWindow?.let { ww -> Text("Weekend times"); TimeRow(ww) { w -> onChange { it.copy(weekendWindow = w) } } }
        }
        if (supportsBreaks) {
            Text("Breaks")
            config.breaks.forEachIndexed { i, b ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TimeRow(b) { nb -> onChange { c -> c.copy(breaks = c.breaks.mapIndexed { j, x -> if (j == i) nb else x }) } }
                    IconButton(onClick = { onChange { c -> c.copy(breaks = c.breaks.filterIndexed { j, _ -> j != i }) } }) {
                        Icon(Icons.Default.Delete, "Remove break")
                    }
                }
            }
            OutlinedButton(onClick = { onChange { it.copy(breaks = it.breaks + TimeRange(15 * 60, 15 * 60 + 30)) } }) { Text("Add break") }
        }
        OutlinedButton(onClick = onManageApps) { Text("Choose restricted & allowed apps") }
    }
}
