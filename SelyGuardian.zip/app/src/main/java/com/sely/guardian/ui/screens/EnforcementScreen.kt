package com.sely.guardian.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.sely.guardian.enforce.Enforcement
import com.sely.guardian.enforce.Mechanism
import com.sely.guardian.ui.GuardianViewModel

@Composable
fun EnforcementScreen(vm: GuardianViewModel) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val notice by vm.notice.collectAsState()
    var tick by remember { mutableStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    val mech = remember(tick, notice) { Enforcement.mechanism(ctx) }
    val isOwner = remember(tick, notice) { Enforcement.isDeviceOwner(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Enforcement setup", style = MaterialTheme.typography.headlineMedium)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Active mechanism: ${mech.label}", color = if (mech == Mechanism.NONE) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                if (mech == Mechanism.NONE) Text("Nothing is blocked until you set up A or B below.")
            }
        }
        notice?.let { Text(it) }

        Text("A. Device Owner (strong)", style = MaterialTheme.typography.titleMedium)
        Text("Android lets one app become the device's manager. Then Sely can suspend apps and the child cannot simply switch it off. " +
            "Android only allows this on a device with no Google or other accounts (usually a freshly reset phone) and it must be set from a computer over USB debugging:")
        SelectionContainer { Text(Enforcement.ADB_COMMAND, style = MaterialTheme.typography.bodySmall) }
        OutlinedButton(onClick = { clip.setText(AnnotatedString(Enforcement.ADB_COMMAND)) }) { Text("Copy command") }
        if (isOwner) {
            OutlinedButton(onClick = { confirm = true }) { Text("Release Device Owner") }
            Text("Warning: this button has no PIN yet (Stage 7). Do not leave the unlocked app with the person being supervised.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Text("B. Accessibility blocker (best-effort)", style = MaterialTheme.typography.titleMedium)
        Text("Works on an ordinary phone. Disclosure: it only learns which app comes to the front; it does not read screen content, typing or passwords. " +
            "When a restricted app opens it sends the phone to the home screen. The device user can turn it off in Settings, so this is not guaranteed.")
        Text("On Android 13+, an APK installed outside the Play Store may need: App info > ⋮ > Allow restricted settings, before the switch works.",
            style = MaterialTheme.typography.bodySmall)
        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
            Text("Open Accessibility settings")
        }
        Button(onClick = { vm.reconcileNow() }) { Text("Re-apply policy now") }
        Text("Always reachable: Settings, the phone/dialer, default SMS, the home launcher and this app are never restricted.", style = MaterialTheme.typography.bodySmall)
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Release Device Owner?") },
        text = { Text("All Sely restrictions will be lifted and Device Owner status removed.") },
        confirmButton = { TextButton(onClick = { confirm = false; vm.releaseDeviceOwner() }) { Text("Release") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
    )
}
