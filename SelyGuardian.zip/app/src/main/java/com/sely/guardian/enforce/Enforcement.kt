package com.sely.guardian.enforce

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import com.sely.guardian.data.*

class GuardianAdminReceiver : DeviceAdminReceiver()

enum class Mechanism(val label: String) {
    DEVICE_OWNER("Device Owner (strong)"),
    ACCESSIBILITY("Accessibility blocker (best-effort)"),
    NONE("None"),
}

object Enforcement {
    const val ADB_COMMAND = "adb shell dpm set-device-owner com.sely.guardian/.enforce.GuardianAdminReceiver"

    fun dpm(ctx: Context) = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    fun admin(ctx: Context) = ComponentName(ctx, GuardianAdminReceiver::class.java)
    fun isDeviceOwner(ctx: Context) = dpm(ctx).isDeviceOwnerApp(ctx.packageName)

    fun isAccessibilityEnabled(ctx: Context): Boolean {
        val me = ComponentName(ctx, GuardianAccessibilityService::class.java)
        val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return list.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    fun mechanism(ctx: Context) = when {
        isDeviceOwner(ctx) -> Mechanism.DEVICE_OWNER
        isAccessibilityEnabled(ctx) -> Mechanism.ACCESSIBILITY
        else -> Mechanism.NONE
    }

    /** Never restricted, so phone calls, emergency dialing, Settings, the launcher and this app stay reachable. */
    fun protectedPackages(ctx: Context): Set<String> {
        val pm = ctx.packageManager
        val out = mutableSetOf(ctx.packageName, "com.android.settings", "com.android.systemui", "com.android.phone", "com.android.emergency")
        fun add(i: Intent) { pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { out += it } }
        add(Intent(Intent.ACTION_DIAL)); add(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); add(Intent(Settings.ACTION_SETTINGS))
        runCatching { (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage }.getOrNull()?.let { out += it }
        runCatching { Telephony.Sms.getDefaultSmsPackage(ctx) }.getOrNull()?.let { out += it }
        return out
    }

    /** Safe unenrollment: lift our suspensions, then give up Device Owner. Not PIN-protected until Stage 7. */
    @Suppress("DEPRECATION")
    fun releaseDeviceOwner(ctx: Context): String {
        if (!isDeviceOwner(ctx)) return "This app is not Device Owner."
        val db = GuardianDb.of(ctx)
        return try {
            val set = Codec.decodeSet(db.get("suspended_pkgs"))
            if (set.isNotEmpty()) dpm(ctx).setPackagesSuspended(admin(ctx), set.toTypedArray(), false)
            db.put("suspended_pkgs", "")
            dpm(ctx).clearDeviceOwnerApp(ctx.packageName)
            db.log("enforcement", "device_owner_released", "released by administrator action")
            "Device Owner released. Restrictions were lifted."
        } catch (e: Exception) { "Release failed: ${e.javaClass.simpleName}" }
    }
}

class DeviceOwnerEnforcer(private val ctx: Context, private val db: GuardianDb) : Enforcer {
    override fun apply(policy: ResolvedPolicy): EnforcementReport {
        val dpm = Enforcement.dpm(ctx); val admin = Enforcement.admin(ctx); val pm = ctx.packageManager
        return try {
            val prot = Enforcement.protectedPackages(ctx)
            val skipped = policy.restricted.count { it in prot }
            val wanted = (policy.restricted - prot).filter { runCatching { pm.getApplicationInfo(it, 0) }.isSuccess }.toSet()
            val previous = Codec.decodeSet(db.get("suspended_pkgs"))
            val stillSuspended = mutableSetOf<String>()
            val lift = previous - wanted
            if (lift.isNotEmpty()) stillSuspended += dpm.setPackagesSuspended(admin, lift.toTypedArray(), false)
            var failed = 0
            if (wanted.isNotEmpty()) failed = dpm.setPackagesSuspended(admin, wanted.toTypedArray(), true).size
            val verified = wanted.filter { runCatching { dpm.isPackageSuspended(admin, it) }.getOrDefault(false) }.toSet()
            db.put("suspended_pkgs", Codec.encodeSet(verified + stillSuspended))
            val ok = verified.size == wanted.size && stillSuspended.isEmpty()
            EnforcementReport(ok, "Device Owner: ${verified.size}/${wanted.size} verified suspended, $failed failed, " +
                "${stillSuspended.size} could not be released, $skipped protected skipped")
        } catch (e: SecurityException) {
            EnforcementReport(false, "Device Owner call refused by Android: ${e.javaClass.simpleName}")
        }
    }
}

class AccessibilityEnforcer(private val ctx: Context, private val db: GuardianDb) : Enforcer {
    override fun apply(policy: ResolvedPolicy): EnforcementReport {
        val wanted = policy.restricted - Enforcement.protectedPackages(ctx)
        db.put("a11y_blocked", Codec.encodeSet(wanted))
        return if (wanted.isEmpty()) EnforcementReport(true, "Accessibility blocker on; no restriction due")
        else EnforcementReport(true, "Accessibility (best-effort, device user can switch it off): watching ${wanted.size} apps")
    }
}

class CompositeEnforcer(ctx: Context) : Enforcer {
    private val app = ctx.applicationContext
    private val db = GuardianDb.of(app)
    override fun apply(policy: ResolvedPolicy): EnforcementReport = when (Enforcement.mechanism(app)) {
        Mechanism.DEVICE_OWNER -> { db.put("a11y_blocked", ""); DeviceOwnerEnforcer(app, db).apply(policy) }
        Mechanism.ACCESSIBILITY -> AccessibilityEnforcer(app, db).apply(policy)
        Mechanism.NONE -> {
            db.put("a11y_blocked", "")
            if (policy.restricted.isEmpty()) EnforcementReport(true, "no restriction due; NO enforcement mechanism set up")
            else EnforcementReport(false, "NOT ENFORCED: ${policy.restricted.size} apps should be restricted but no mechanism is set up")
        }
    }
}
