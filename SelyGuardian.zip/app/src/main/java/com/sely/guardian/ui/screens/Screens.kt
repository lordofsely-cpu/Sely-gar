package com.sely.guardian.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.sely.guardian.data.ScheduleCalc
import com.sely.guardian.enforce.Enforcement
import com.sely.guardian.enforce.Mechanism
import com.sely.guardian.location.LocationState
import com.sely.guardian.screenshare.ScreenShareState
import com.sely.guardian.ui.Feature
import com.sely.guardian.ui.GuardianViewModel
import com.sely.guardian.ui.features
import java.time.LocalDateTime

@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("SELY GUARDIAN", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text("Transparent parental supervision and authorized device management.", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(8.dp))
        Text("Designed by Kingsley", style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(32.dp))
        Button(onClick = onContinue) { Text("Get started") }
    }
}

@Composable
private fun InfoCard(title: String, body: String, alert: Boolean = false, onClick: (() -> Unit)? = null) {
    val content: @Composable ColumnScope.() -> Unit = {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodyMedium,
                color = if (alert) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        }
    }
    if (onClick != null) Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), content = content)
    else Card(modifier = Modifier.fillMaxWidth(), content = content)
}

@Composable
fun DashboardScreen(vm: GuardianViewModel, onOpen: (String) -> Unit) {
    val study by vm.study.collectAsState()
    val bed by vm.bedtime.collectAsState()
    val sel by vm.selection.collectAsState()
    val now = LocalDateTime.now()
    val mech = Enforcement.mechanism(LocalContext.current)
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Dashboard", style = MaterialTheme.typography.headlineMedium) }
        item {
            InfoCard("Protection", "Mechanism: ${mech.label}" + if (mech == Mechanism.NONE) ". NOTHING IS BLOCKED. Tap to set up." else ". Tap for details.",
                alert = mech == Mechanism.NONE, onClick = { onOpen("enforcement") })
        }
        item { InfoCard("Study Mode", ScheduleCalc.state(study, now).label, onClick = { onOpen("study") }) }
        item { InfoCard("Bedtime Mode", ScheduleCalc.state(bed, now).label, onClick = { onOpen("bedtime") }) }
        item { InfoCard("Restricted apps", "${sel.restricted.size} restricted · ${sel.allowed.size} allowed", onClick = { onOpen("apps") }) }
        item { InfoCard("Screen time", "Needs Usage Access. Tap to view reports and history.", onClick = { onOpen("reports") }) }
        item {
            val loc by LocationState.flow.collectAsState()
            InfoCard("Location sharing", if (loc.active) "ACTIVE every ${loc.intervalSec / 60} min (local only)" else "Off",
                alert = loc.active, onClick = { onOpen("location") })
        }
        item {
            val shr by ScreenShareState.flow.collectAsState()
            InfoCard("Screen sharing", if (shr.active) "ACTIVE (capture only, nothing sent)" else "Off", alert = shr.active, onClick = { onOpen("screen") })
        }
        item { InfoCard("Schedule diagnostics", "Alarm status and execution log", onClick = { onOpen("diagnostics") }) }
        item { InfoCard("Last sync", "Never (no backend yet)") }
        item { InfoCard("Recent security events", "None recorded (event log arrives in Stage 7)") }
        items(features.filter { it.route in setOf("admin") }) { f ->
            InfoCard(f.title, "Stage ${f.stage} · ${f.status.label}", onClick = { onOpen(f.route) })
        }
    }
}

@Composable
fun FeatureStubScreen(f: Feature) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(f.title, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Status: ${f.status.label} (planned for stage ${f.stage})")
        Text(f.note, style = MaterialTheme.typography.bodySmall)
    }
}
