package com.sely.guardian.data

import java.time.LocalDate

data class UsageEvent(val pkg: String, val cls: String, val type: Int, val time: Long)
data class Session(val pkg: String, val start: Long, val end: Long)
data class AppUsage(val pkg: String, val name: String, val millis: Long)
data class UsageReport(
    val hasAccess: Boolean, val todayTotal: Long, val todayTop: List<AppUsage>,
    val weekTotal: Long, val weekTop: List<AppUsage>, val daily: List<Pair<LocalDate, Long>>, val error: String? = null,
) {
    companion object { val NONE = UsageReport(false, 0, emptyList(), 0, emptyList(), emptyList()) }
}

/** Pure foreground-time maths over UsageEvents (RESUMED=1, PAUSED=2). Approximate: see README. */
object UsageCalc {
    const val RESUMED = 1
    const val PAUSED = 2

    fun sessions(events: List<UsageEvent>, rangeStart: Long, rangeEnd: Long): List<Session> {
        val open = HashMap<String, Long>()
        val out = mutableListOf<Session>()
        for (e in events.sortedBy { it.time }) {
            val key = e.pkg + "/" + e.cls
            when (e.type) {
                RESUMED -> {
                    open[key]?.let { if (e.time > it) out += Session(e.pkg, it, e.time) }  // missed pause: close earlier session
                    open[key] = e.time
                }
                PAUSED -> {
                    val s = open.remove(key) ?: rangeStart                                   // started before the range
                    if (e.time > s) out += Session(e.pkg, s, e.time)
                }
            }
        }
        open.forEach { (k, s) -> if (rangeEnd > s) out += Session(k.substringBefore("/"), s, rangeEnd) }
        return out
    }

    fun totals(sessions: List<Session>, from: Long, to: Long): Map<String, Long> {
        val m = HashMap<String, Long>()
        for (s in sessions) {
            val d = minOf(s.end, to) - maxOf(s.start, from)
            if (d > 0) m[s.pkg] = (m[s.pkg] ?: 0L) + d
        }
        return m
    }

    fun fmtDuration(ms: Long): String {
        val min = ms / 60000
        return when {
            min >= 60 -> "%dh %02dm".format(min / 60, min % 60)
            min >= 1 -> "${min}m"
            else -> "<1m"
        }
    }
}
