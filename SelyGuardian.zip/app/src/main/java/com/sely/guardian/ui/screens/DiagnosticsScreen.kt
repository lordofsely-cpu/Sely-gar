package com.sely.guardian.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sely.guardian.enforce.Enforcement
import com.sely.guardian.enforce.Mechanism
import com.sely.guardian.ui.GuardianViewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val fmt = DateTimeFormatter.ofPattern("MMM d HH:mm:ss")
private fun fmtMs(ms: Long) = fmt.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

@Composable
fun DiagnosticsScreen(vm: GuardianViewModel) {
    val d by vm.diag.collectAsState()
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.refreshDiagnostics() }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Schedule diagnostics", style = MaterialTheme.typography.headlineMedium) }
        val x = d
        if (x == null) { item { Text("Loading…") }; return@LazyColumn }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Exact alarms: " + if (x.exactAlarmsAllowed) "allowed" else "NOT allowed (transitions may be delayed)",
                        color = if (x.exactAlarmsAllowed) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error)
                    Text(if (x.nextAtMillis != null) "Next transition: ${x.nextMode} → ${x.nextState} at ${fmtMs(x.nextAtMillis)}" +
                        " (${if (x.nextExact == true) "exact" else "inexact"} alarm)" else "Next transition: none scheduled")
                    Text("Last policy: ${x.lastPolicy ?: "none yet"}", style = MaterialTheme.typography.bodySmall)
                    val m = Enforcement.mechanism(ctx)
                    Text("Enforcement mechanism: ${m.label}" + if (m == Mechanism.NONE) " (nothing is blocked)" else "", color = if (m == Mechanism.NONE) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.reconcileNow() }) { Text("Reconcile now") }
                if (!x.exactAlarmsAllowed && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    OutlinedButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
                    }) { Text("Allow exact alarms") }
                }
            }
        }
        item { Text("Execution log (latest first)", style = MaterialTheme.typography.titleMedium) }
        if (x.log.isEmpty()) item { Text("No entries yet.") }
        items(x.log) { r -> Text("${fmtMs(r.ts)}  ${r.mode}/${r.event}: ${r.detail}", style = MaterialTheme.typography.bodySmall) }
    }
}
