package com.sely.guardian.data

import android.content.Context

/** Plain string codec so persistence is unit-testable on the JVM. */
object Codec {
    private fun enc(r: TimeRange) = "${r.startMin}-${r.endMin}"
    private fun dec(s: String): TimeRange { val p = s.split("-"); return TimeRange(p[0].toInt(), p[1].toInt()) }

    fun encode(c: ModeConfig): String = listOf(
        c.enabled.toString(), c.days.sorted().joinToString(","), enc(c.window),
        c.weekendWindow?.let(::enc) ?: "", c.breaks.joinToString(";") { enc(it) },
    ).joinToString("|")

    fun decode(s: String?, default: ModeConfig): ModeConfig = try {
        if (s == null) default else {
            val p = s.split("|")
            ModeConfig(
                enabled = p[0].toBooleanStrict(),
                days = p[1].split(",").filter { it.isNotBlank() }.map { it.toInt() }.toSet(),
                window = dec(p[2]),
                weekendWindow = p[3].takeIf { it.isNotBlank() }?.let(::dec),
                breaks = p[4].split(";").filter { it.isNotBlank() }.map(::dec),
            )
        }
    } catch (e: Exception) { default }

    fun encodeSet(s: Set<String>) = s.sorted().joinToString(",")
    fun decodeSet(s: String?): Set<String> = s?.split(",")?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
}

/** Config lives in the SQLite kv table; falls back to the Stage 2 SharedPreferences values until first saved. */
class SettingsStore(ctx: Context) {
    private val db = GuardianDb.of(ctx)
    private val legacy = ctx.applicationContext.getSharedPreferences("sely_settings", Context.MODE_PRIVATE)
    fun loadMode(key: String, default: ModeConfig) = Codec.decode(db.get("mode_$key") ?: legacy.getString(key, null), default)
    fun saveMode(key: String, c: ModeConfig) = db.put("mode_$key", Codec.encode(c))
    fun loadSelection() = AppSelection(
        Codec.decodeSet(db.get("restricted") ?: legacy.getString("restricted", null)),
        Codec.decodeSet(db.get("allowed") ?: legacy.getString("allowed", null)),
    )
    fun saveSelection(s: AppSelection) {
        db.put("restricted", Codec.encodeSet(s.restricted)); db.put("allowed", Codec.encodeSet(s.allowed))
    }
}
