package com.sely.guardian.screenshare

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.sely.guardian.MainActivity
import kotlinx.coroutines.flow.update

object ScreenShareControl {
    fun start(ctx: Context, resultCode: Int, data: Intent) = ContextCompat.startForegroundService(
        ctx, Intent(ctx, ScreenShareService::class.java)
            .putExtra(ScreenShareService.EXTRA_CODE, resultCode).putExtra(ScreenShareService.EXTRA_DATA, data))
    fun stop(ctx: Context) { ctx.stopService(Intent(ctx, ScreenShareService::class.java)) }
}

/**
 * Visible foreground service holding a MediaProjection granted through Android's own consent dialog.
 * Captures low-resolution frames (about 2/s) into [DiscardSink]; no remote viewing exists yet.
 * Stops when the user stops it (notification, app, or the system's own stop control) or Android revokes the projection.
 */
class ScreenShareService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private val throttle = FrameThrottle(500)
    private val sink: FrameSink = DiscardSink
    private var sinkFailures = 0
    private var size = 2 to 2

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() {
            ScreenShareState.flow.update { it.copy(message = "Sharing was stopped (by you, the system, or because permission ended).") }
            stopSelf()
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("sely-capture").also { it.start() }
        handler = Handler(thread.looper)
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        try { startInForeground() } catch (e: Exception) {
            ScreenShareState.flow.update { it.copy(active = false, message = "Could not show the sharing notification (${e.javaClass.simpleName}).") }
            stopSelf(); return START_NOT_STICKY
        }
        val code = i?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra(EXTRA_DATA, Intent::class.java) else i?.getParcelableExtra(EXTRA_DATA)
        if (code != Activity.RESULT_OK || data == null) { fail("Screen sharing consent result was missing."); return START_NOT_STICKY }
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projection = mpm.getMediaProjection(code, data).also { it.registerCallback(callback, handler) }  // callback BEFORE createVirtualDisplay (Android 14)
            startCapture()
        } catch (e: Exception) { fail("Could not start screen capture (${e.javaClass.simpleName}).") }
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Screen sharing", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 4, Intent(this, ScreenShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 5, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Sely Guardian: screen sharing is ON").setContentText("Your screen is being captured. Tap Stop to end.")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(ID, n)
    }

    @Suppress("DEPRECATION")
    private fun screen(): Triple<Int, Int, Int> {
        val wm = getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds; Triple(b.width(), b.height(), resources.displayMetrics.densityDpi)
        } else { val dm = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(dm); Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi) }
    }

    private fun makeReader(w: Int, h: Int): ImageReader =
        ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2).also { r ->
            r.setOnImageAvailableListener({ rd ->
                val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    if (throttle.shouldProcess(SystemClock.elapsedRealtime())) {
                        sink.onFrame(w, h, img); sinkFailures = 0
                        ScreenShareState.flow.update { it.copy(frames = it.frames + 1, lastFrameMs = System.currentTimeMillis()) }
                    }
                } catch (e: Exception) {
                    if (++sinkFailures >= 3) fail("Frame delivery failed repeatedly, so sharing was stopped.")
                } finally { img.close() }
            }, handler)
        }

    private fun startCapture() {
        val (w, h, dpi) = screen()
        size = ScreenGeometry.scaled(w, h, 480)
        reader = makeReader(size.first, size.second)
        display = projection!!.createVirtualDisplay("sely-share", size.first, size.second, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        ScreenShareState.flow.update {
            it.copy(active = true, frames = 0, width = size.first, height = size.second,
                startedMs = System.currentTimeMillis(), lastFrameMs = null, sink = sink.description, message = null)
        }
    }

    /** Rotation: rebuild the reader at the new size and point the virtual display at it. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val d = display ?: return
        try {
            val (w, h, dpi) = screen()
            val s = ScreenGeometry.scaled(w, h, 480)
            if (s == size) return
            size = s
            val old = reader
            reader = makeReader(s.first, s.second)
            d.resize(s.first, s.second, dpi); d.surface = reader!!.surface
            old?.close()
            ScreenShareState.flow.update { it.copy(width = s.first, height = s.second) }
        } catch (e: Exception) { fail("Could not adjust to the new screen orientation.") }
    }

    private fun fail(msg: String) {
        ScreenShareState.flow.update { it.copy(active = false, message = msg) }
        stopSelf()
    }

    override fun onDestroy() {
        try { display?.release() } catch (_: Exception) { }
        try { reader?.close() } catch (_: Exception) { }
        projection?.let { try { it.unregisterCallback(callback); it.stop() } catch (_: Exception) { } }
        thread.quitSafely()
        ScreenShareState.flow.update { it.copy(active = false) }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.sely.guardian.SCREEN_STOP"
        private const val CH = "screen_sharing"
        private const val ID = 4202
    }
}
