package com.sely.guardian.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

private fun BroadcastReceiver.reconcileAsync(ctx: Context, reason: String) {
    val pending = goAsync()
    Thread {
        try { ScheduleManager(ctx).reconcile(reason) } catch (_: Exception) { } finally { pending.finish() }
    }.start()
}

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ScheduleManager.ACTION_ALARM) reconcileAsync(context, "alarm")
    }
}

/** Boot, time-zone change, clock change and app update all just trigger a full reconcile. */
class SystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val reason = when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> "boot"
            Intent.ACTION_TIMEZONE_CHANGED -> "timezone"
            Intent.ACTION_TIME_CHANGED -> "time_set"
            Intent.ACTION_MY_PACKAGE_REPLACED -> "app_updated"
            else -> return
        }
        reconcileAsync(context, reason)
    }
}

/** Hourly safety net in case an alarm was lost; unique work so it is never duplicated. */
class ReconcileWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try { ScheduleManager(applicationContext).reconcile("work"); Result.success() } catch (e: Exception) { Result.retry() }
    }

    companion object {
        fun ensureScheduled(ctx: Context) {
            val req = PeriodicWorkRequest.Builder(ReconcileWorker::class.java, 1, TimeUnit.HOURS).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("sely_reconcile", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
