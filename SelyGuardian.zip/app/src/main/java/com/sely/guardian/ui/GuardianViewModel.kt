package com.sely.guardian.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sely.guardian.data.*
import com.sely.guardian.engine.Diagnostics
import com.sely.guardian.enforce.Enforcement
import com.sely.guardian.location.FixCodec
import com.sely.guardian.location.LocationState
import com.sely.guardian.engine.ScheduleManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class GuardianViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val repo = AppRepository(app)
    private val manager = ScheduleManager(app)
    private val _diag = MutableStateFlow<Diagnostics?>(null)
    val diag: StateFlow<Diagnostics?> = _diag
    private val db = GuardianDb.of(app)
    private val usageRepo = UsageRepository(app)
    private val _usage = MutableStateFlow<UsageReport?>(null)
    val usage: StateFlow<UsageReport?> = _usage
    private val _history = MutableStateFlow<List<LogRow>>(emptyList())
    val history: StateFlow<List<LogRow>> = _history
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice

    private val _study = MutableStateFlow(store.loadMode("study", Defaults.study))
    private val _bedtime = MutableStateFlow(store.loadMode("bedtime", Defaults.bedtime))
    private val _selection = MutableStateFlow(store.loadSelection())
    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    private val _loading = MutableStateFlow(true)

    val study: StateFlow<ModeConfig> = _study
    val bedtime: StateFlow<ModeConfig> = _bedtime
    val selection: StateFlow<AppSelection> = _selection
    val apps: StateFlow<List<AppEntry>> = _apps
    val loading: StateFlow<Boolean> = _loading

    init {
        viewModelScope.launch(Dispatchers.IO) {
            _apps.value = try { repo.loadLaunchableApps() } catch (e: Exception) { emptyList() }
            _loading.value = false
        }
        viewModelScope.launch(Dispatchers.IO) {
            LocationState.flow.update { it.copy(fix = it.fix ?: FixCodec.decode(db.get("loc_last"))) }
        }
        reconcile("app_start")
    }

    fun updateStudy(f: (ModeConfig) -> ModeConfig) { _study.update(f); store.saveMode("study", _study.value); reconcile("config_changed") }
    fun updateBedtime(f: (ModeConfig) -> ModeConfig) { _bedtime.update(f); store.saveMode("bedtime", _bedtime.value); reconcile("config_changed") }

    fun setRestricted(pkg: String, on: Boolean) = updateSelection {
        AppSelection(if (on) it.restricted + pkg else it.restricted - pkg, if (on) it.allowed - pkg else it.allowed)
    }
    fun setAllowed(pkg: String, on: Boolean) = updateSelection {
        AppSelection(if (on) it.restricted - pkg else it.restricted, if (on) it.allowed + pkg else it.allowed - pkg)
    }
    private fun updateSelection(f: (AppSelection) -> AppSelection) { _selection.update(f); store.saveSelection(_selection.value); reconcile("config_changed") }

    private fun reconcile(reason: String) {
        viewModelScope.launch(Dispatchers.IO) { try { manager.reconcile(reason) } catch (_: Exception) { } }
    }
    fun releaseDeviceOwner() {
        viewModelScope.launch(Dispatchers.IO) {
            _notice.value = Enforcement.releaseDeviceOwner(getApplication<Application>())
            try { manager.reconcile("owner_released") } catch (_: Exception) { }
        }
    }
    fun refreshUsage() {
        viewModelScope.launch(Dispatchers.IO) {
            _usage.value = try { usageRepo.loadReport() } catch (e: Exception) { UsageReport.NONE.copy(error = "Could not read usage data: ${e.javaClass.simpleName}") }
            _history.value = db.recentLogWhere(listOf("state_change", "blocked_launch"), 100)
        }
    }
    fun deleteStoredLocation() {
        viewModelScope.launch(Dispatchers.IO) { db.delete("loc_last"); LocationState.flow.update { it.copy(fix = null, lastUpdateMs = null) } }
    }
    fun refreshDiagnostics() { viewModelScope.launch(Dispatchers.IO) { _diag.value = manager.diagnostics() } }
    fun reconcileNow() {
        viewModelScope.launch(Dispatchers.IO) {
            try { manager.reconcile("manual") } catch (_: Exception) { }
            _diag.value = manager.diagnostics()
        }
    }
}
