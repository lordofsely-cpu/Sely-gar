# Sely Guardian (Designed by Kingsley)
Status: **Stage 6 of 8**. Not compiled in the authoring environment (no network) — first real build is yours.

## Implemented (unverified on a device)
- Stage 2 UI: dashboard, app management, Study/Bedtime settings.
- Stage 3 engine (`engine/`, `data/`): SQLite store (config + execution log), pure schedule math incl. next-transition,
  overlap policy, one exact (or inexact fallback) alarm, boot/time-zone/clock-change/app-update receivers,
  hourly WorkManager safety net, Diagnostics screen.
- Stage 4 enforcement (`enforce/`), all UNTESTED on a device: Device Owner via `DevicePolicyManager.setPackagesSuspended`
  (with verification via `isPackageSuspended`), opt-in Accessibility blocker (package name only), restriction screen,
  protected packages (dialer, SMS, Settings, launcher, this app), safe "Release Device Owner".
- Stage 5 (UNTESTED on a device): screen-time reports from `UsageStatsManager.queryEvents` (Usage Access; empty state when off;
  approximate), Study/Bedtime history and restriction events from the log; location sharing via a visible foreground service
  (ongoing notification with Stop, interval 1/5/15 min, fine or approximate location, local only, never auto-resumes).
- Stage 6 (UNTESTED on a device): MediaProjection screen capture behind Android's consent dialog, visible foreground service with Stop,
  low-res throttled capture into a discard sink, stops on system stop/revocation/repeated sink failure, rotation handling.
## NOT implemented
- Remote viewing and remote location (need backend; see docs/REMOTE_SCREEN_SHARING.md), PIN (Release Device Owner is unprotected until Stage 7), backend.
- Instrumented/Device Owner tests: need an emulator or spare phone provisioned with `adb shell dpm set-device-owner`.
## Rules
- Overlap: if either mode is ACTIVE, restrictions apply (union). A Study break never lifts Bedtime. Restricted = restricted − allowed.
- Overnight windows belong to the day they start; weekend times apply to windows starting Sat/Sun.
- State changes are logged when *detected*; if the phone was off, the log shows detection time, not the true transition.
- Exact alarms need the "Alarms & reminders" permission on Android 13+; otherwise inexact alarms are used and Diagnostics says so.
## Manual device tests (not automated)
1. Enable Study Mode for a window starting 2 minutes from now; wait; check Diagnostics log for `reconcile:alarm` and a `state_change`.
2. Reboot the phone; open Diagnostics: expect `reconcile:boot`. 3. Change time zone in system settings: expect `reconcile:timezone`.
## Build
GitHub Actions builds `SelyGuardian-debug`. Locally `gradle assembleDebug`; tests `gradle testDebugUnitTest`.

## Enforcement notes
- Device Owner: `adb shell dpm set-device-owner com.sely.guardian/.enforce.GuardianAdminReceiver` (no accounts on device; needs a computer).
  Suspended apps show Android's own "app paused" dialog; a custom Sely message is NOT guaranteed there.
- Accessibility blocker: user must enable it; can be switched off; Android 13+ may require "Allow restricted settings" for sideloaded APKs.
  Whether Android lets it open the Sely restriction screen on top is unverified; Home is always pressed.
- Neither mechanism makes Sely impossible to uninstall or bypass, and none is claimed.

## Manual tests for screen sharing (not automated)
Deny the consent dialog; stop from the app, from the notification and from Android's own control; rotate the phone while sharing;
lock the screen; swipe the app away; open a banking/video app (may be blank). Check the frame counter and the dashboard card each time.
